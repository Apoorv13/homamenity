A Pen created at CodePen.io. You can find this one at http://codepen.io/adamdroid/pen/ZboYvb.

 Toggle between 'grid' and 'list' view in product listings.